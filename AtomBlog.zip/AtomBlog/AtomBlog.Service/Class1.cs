﻿namespace AtomBlog.Service;
public class Class1
{

}
