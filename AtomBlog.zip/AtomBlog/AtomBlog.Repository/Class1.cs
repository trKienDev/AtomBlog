﻿namespace AtomBlog.Repository;
public class Class1
{

}
