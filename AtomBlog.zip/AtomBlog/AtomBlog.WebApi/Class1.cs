﻿namespace AtomBlog.WebApi;
public class Class1
{

}
