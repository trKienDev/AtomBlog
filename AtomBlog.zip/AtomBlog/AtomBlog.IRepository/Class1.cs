﻿namespace AtomBlog.IRepository;
public class Class1
{

}
