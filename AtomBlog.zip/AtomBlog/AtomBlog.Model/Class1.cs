﻿namespace AtomBlog.Model;
public class Class1
{

}
