﻿namespace AtomBlog.IService;
public class Class1
{

}
